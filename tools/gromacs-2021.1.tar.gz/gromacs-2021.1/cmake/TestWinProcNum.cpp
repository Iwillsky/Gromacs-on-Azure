#define _WIN32_WINNT 0x0601 /*Require Windows7 (needed for MingW)*/
#include <windows.h>
int main()
{
    PROCESSOR_NUMBER p;
    return 0;
}
